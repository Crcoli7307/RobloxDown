from flask import Flask, make_response, render_template
from termcolor import colored
import datetime, os, logging, smtplib, ssl

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

sendemails = True

avgping = 0
highping = False
lowestping = 0
highestping = 0

app = Flask(__name__)

@app.route("/")
def index():
  return f"""<meta http-equiv="refresh" content="1"><h2>Roblox Ping Latency Tester</h2> <p>Average Ping: {avgping}ms</p>"""

@app.route("/pingdata")
def pingdata():
  return f"{avgping}ms"
  

@app.route('/initial/<clientplatforminfo>/<clienttime>/<clientcountry>/<clientcity>/<clientip>')
def initial(clientplatforminfo, clienttime, clientcountry, clientcity, clientip):
  clientcity = clientcity.replace("_"," ")
  currenttime = str(datetime.datetime.now()).split(' ')[1].split('.')[0]
  currentsecond = currenttime.split(':')[2]
  if not os.path.exists(f"clientmemory/{clientip}.txt"):
    clientinfofile = open(f"clientmemory/{clientip}.txt", "w")
    clientinfo = f"{clientplatforminfo}\n{clientcountry}\n{clientcity}\n{clientip}"
    clientinfofile.write(clientinfo)
    print(colored(f"Client Check-In Request - Location: {clientcity}, {clientcountry} - IP Address: {clientip} - Platform: {clientplatforminfo}", "grey", "on_white"))
    return "{" + f""" "serverreply": "200", "servertime": "{currentsecond}" """+ "}"
  else:
    os.remove(f"clientmemory/{clientip}.txt")
    clientinfofile = open(f"clientmemory/{clientip}.txt", "w")
    clientinfo = f"{clientplatforminfo}\n{clientcountry}\n{clientcity}\n{clientip}"
    clientinfofile.write(clientinfo)
    print(colored(f"Client Check-In Request (Duplicate) - Location: {clientcity}, {clientcountry} - IP Address: {clientip} - Platform: {clientplatforminfo}", "grey", "on_white"))
    return "{" + f""" "serverreply": "200", "servertime": "{currentsecond}" """+ "}"

@app.route('/ping/<clienttime>/<clientip>/<pingdata>')
def ping(clienttime, clientip, pingdata):
  try:
    global avgping
    global lowestping
    global highestping
    global highping
    currenttime = str(datetime.datetime.now()).split(' ')[1].split('.')[0]
    currentsecond = currenttime.split(':')[2]
    pingsfile = open("pings.txt", "a")
    pingsfile.write(pingdata+'\n')
    pingsfile.close()
    readpings = open("pings.txt", "r")
    pings = readpings.read().split("\n")
    pings = [ping for ping in pings if ping != ""]
    if len(pings) > 16:
      os.remove("pings.txt")
      return "{" + f""" "serverreply": "200", "servertime": "{currentsecond}" """+ "}"
      avgping = 0
    pings = [int(ping) for ping in pings]
    avgping = str(sum(pings) / len(pings)).split(".")[0]
    if int(avgping) > 1000:
      highping = True
      if currentsecond == "00" and sendemails == True:
        port = 465 
        smtp_server = "smtp.mailgun.org"
        sender_email = "robloxlatency@fenixsoftware.org"
        password = "63f780ae4be95b4c6374609b3bc27b68-ef80054a-1007b674"
        message = f"""\
      Subject: Possible Outage at Roblox!

      Our servers have detected that there is an average high ping time at Roblox, higher than usual ({avgping}ms). Be aware of possible server overloads and crashes at Roblox.

      This is an automated message sent from Fenix Software, for questions and concerns, please message me on Discord, Crcoli737#1875.
      """
        context = ssl.create_default_context()
        emails = open("emails.txt", "r").read().split("/n")
        for email in emails:
          with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, email, message)
      
    else: 
      highping = False
    lowestping = min(pings)
    highestping = max(pings)
    if clienttime == currentsecond and os.path.exists(f"clientmemory/{clientip}.txt"):
      logs = open("logs.txt", "a")
      clientdatafile = open(f"clientmemory/{clientip}.txt", "r")
      clientdata = clientdatafile.read().split("\n")
      if int(pingdata) > 1000:
        logs.write(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms (HIGH PING!!)\n")
        print(colored(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms (HIGH PING!!)", "white", "on_red"))
      else:
        logs.write(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms\n")
        print(colored(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms", "yellow"))
      return "{" + f""" "serverreply": "200", "servertime": "true" """+ "}"
    else:
      logs = open("logs.txt", "a")
      clientdatafile = open(f"clientmemory/{clientip}.txt", "r")
      clientdata = clientdatafile.read().split("\n")
      if int(pingdata) > 1000:
        logs.write(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms (HIGH PING!!)\n")
        print(colored(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms (HIGH PING!!)", "white", "on_red"))
      else:
        logs.write(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms\n")
        print(colored(f"Ping recieved from {clientdata[3]} ({clientdata[2]}, {clientdata[1]}) at {currenttime} the ping time was {pingdata}ms", "yellow"))
      return "{" + f""" "serverreply": "200", "servertime": "{currentsecond}" """+ "}"
  except Exception as e:
    print(colored(f"Script Errored: {e}", "red", "on_yellow"))
    return "{" + f""" "serverreply": "200", "servertime": "{currentsecond}" """+ "}"



if __name__ == "__main__": 
	app.run(
		host='0.0.0.0',
		port=80
  )